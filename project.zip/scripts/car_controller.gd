extends CharacterBody3D

@export var max_speed := 35.0
@export var accel := 14.0
@export var brake_force := 28.0
@export var steer_speed := 2.2
@export var gravity := 20.0

var speed := 0.0

func _physics_process(delta: float) -> void:
	var throttle := Input.get_action_strength("throttle")
	var brake := Input.get_action_strength("brake")
	var steer := Input.get_axis("steer_left", "steer_right")

	if throttle > 0.0:
		speed = move_toward(speed, max_speed, accel * throttle * delta)
	if brake > 0.0:
		speed = move_toward(speed, 0.0, brake_force * brake * delta)
	else:
		speed = move_toward(speed, 0.0, 4.0 * delta)

	if absf(speed) > 0.5:
		rotate_y(-steer * steer_speed * delta * clampf(speed / 10.0, 0.0, 1.0))

	var forward := -global_transform.basis.z
	velocity.x = forward.x * speed
	velocity.z = forward.z * speed
	velocity.y -= gravity * delta
	move_and_slide()
