extends Node3D

const BLOCK_SIZE := 60.0
const ROAD_WIDTH := 14.0
const GRID := 8

var car
var cam: Camera3D
var speed_label: Label
var rng := RandomNumberGenerator.new()

func _ready() -> void:
	Engine.max_fps = 60
	rng.seed = 1234
	_setup_input()
	_build_world()
	_spawn_car()
	cam = Camera3D.new()
	cam.fov = 70
	cam.far = 1200.0
	add_child(cam)
	cam.current = true
	_build_hud()

func _process(delta: float) -> void:
	if car == null:
		return
	var behind: Vector3 = car.global_transform.basis.z * 8.0
	var target: Vector3 = car.global_position + behind + Vector3.UP * 3.5
	cam.global_position = cam.global_position.lerp(target, clampf(delta * 6.0, 0.0, 1.0))
	cam.look_at(car.global_position + Vector3.UP * 1.2)
	speed_label.text = "%d km/h" % int(absf(car.speed) * 3.6)

func _setup_input() -> void:
	_add_key_action("throttle", KEY_W)
	_add_key_action("brake", KEY_S)
	_add_key_action("steer_left", KEY_A)
	_add_key_action("steer_right", KEY_D)

func _add_key_action(action: String, keycode: Key) -> void:
	if not InputMap.has_action(action):
		InputMap.add_action(action)
	var ev := InputEventKey.new()
	ev.physical_keycode = keycode
	InputMap.action_add_event(action, ev)

func _mat(color: Color, rough: float = 0.8) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = rough
	return m

func _add_box(size: Vector3, pos: Vector3, mat: Material) -> void:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.position = pos
	mi.material_override = mat
	add_child(mi)

func _build_world() -> void:
	# Sky, fog and filmic tone mapping for a realistic-looking sunny city
	var sky := Sky.new()
	sky.sky_material = ProceduralSkyMaterial.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.fog_enabled = true
	env.fog_light_color = Color(0.72, 0.8, 0.88)
	env.fog_density = 0.003
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	var world_env := WorldEnvironment.new()
	world_env.environment = env
	add_child(world_env)

	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-55, 35, 0)
	sun.light_energy = 1.1
	sun.shadow_enabled = false
	add_child(sun)

	# Ground with collision
	var ground_mat := _mat(Color(0.3, 0.33, 0.28), 0.95)
	var ground := MeshInstance3D.new()
	var plane := PlaneMesh.new()
	plane.size = Vector2(2000, 2000)
	ground.mesh = plane
	ground.material_override = ground_mat
	add_child(ground)

	var floor_body := StaticBody3D.new()
	var floor_shape := CollisionShape3D.new()
	var floor_box := BoxShape3D.new()
	floor_box.size = Vector3(2000, 1, 2000)
	floor_shape.shape = floor_box
	floor_shape.position = Vector3(0, -0.5, 0)
	floor_body.add_child(floor_shape)
	add_child(floor_body)

	# Road grid
	var total := GRID * 2 * BLOCK_SIZE
	var road_mat := _mat(Color(0.1, 0.1, 0.11), 0.9)
	for i in range(-GRID, GRID + 1):
		var c := i * BLOCK_SIZE
		_add_box(Vector3(ROAD_WIDTH, 0.05, total), Vector3(c, 0.025, 0), road_mat)
		_add_box(Vector3(total, 0.05, ROAD_WIDTH), Vector3(0, 0.025, c), road_mat)

	# Buildings in one MultiMesh (single draw call for the whole city)
	var bmat := StandardMaterial3D.new()
	bmat.vertex_color_use_as_albedo = true
	bmat.roughness = 0.85
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.use_colors = true
	mm.mesh = BoxMesh.new()
	var side := GRID * 2
	mm.instance_count = side * side
	var idx := 0
	var lot := BLOCK_SIZE - ROAD_WIDTH - 6.0
	for i in range(-GRID, GRID):
		for j in range(-GRID, GRID):
			var h := rng.randf_range(8.0, 55.0)
			var sx := lot * rng.randf_range(0.6, 1.0)
			var sz := lot * rng.randf_range(0.6, 1.0)
			var pos := Vector3((i + 0.5) * BLOCK_SIZE, h * 0.5, (j + 0.5) * BLOCK_SIZE)
			mm.set_instance_transform(idx, Transform3D(Basis().scaled(Vector3(sx, h, sz)), pos))
			mm.set_instance_color(idx, Color.from_hsv(0.08, rng.randf_range(0.0, 0.15), rng.randf_range(0.45, 0.8)))
			idx += 1
	var city := MultiMeshInstance3D.new()
	city.multimesh = mm
	city.material_override = bmat
	add_child(city)

func _spawn_car() -> void:
	car = CharacterBody3D.new()
	car.set_script(load("res://scripts/car_controller.gd"))
	car.name = "PlayerCar"

	var body := MeshInstance3D.new()
	var body_mesh := BoxMesh.new()
	body_mesh.size = Vector3(2.0, 0.9, 4.2)
	body.mesh = body_mesh
	body.position = Vector3(0, 0.6, 0)
	body.material_override = _mat(Color(0.7, 0.05, 0.05), 0.35)
	car.add_child(body)

	var cabin := MeshInstance3D.new()
	var cabin_mesh := BoxMesh.new()
	cabin_mesh.size = Vector3(1.7, 0.7, 2.2)
	cabin.mesh = cabin_mesh
	cabin.position = Vector3(0, 1.25, -0.2)
	var glass := _mat(Color(0.05, 0.07, 0.1), 0.1)
	glass.metallic = 0.3
	cabin.material_override = glass
	car.add_child(cabin)

	var shape := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = Vector3(2.0, 1.6, 4.2)
	shape.shape = box
	shape.position = Vector3(0, 0.8, 0)
	car.add_child(shape)

	add_child(car)
	car.position = Vector3(0, 0.05, 0)

func _build_hud() -> void:
	var hud := CanvasLayer.new()
	add_child(hud)

	speed_label = Label.new()
	speed_label.position = Vector2(30, 20)
	speed_label.add_theme_font_size_override("font_size", 42)
	hud.add_child(speed_label)

	var root := Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(root)

	var bar := HBoxContainer.new()
	bar.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
	bar.offset_left = 30
	bar.offset_right = -30
	bar.offset_top = -150
	bar.offset_bottom = -20
	bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(bar)

	var left := HBoxContainer.new()
	left.add_theme_constant_override("separation", 14)
	bar.add_child(left)
	_touch_button(left, "<", "steer_left")
	_touch_button(left, ">", "steer_right")

	var spacer := Control.new()
	spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	spacer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bar.add_child(spacer)

	var right := HBoxContainer.new()
	right.add_theme_constant_override("separation", 14)
	bar.add_child(right)
	_touch_button(right, "BRAKE", "brake")
	_touch_button(right, "GAS", "throttle")

func _touch_button(parent: Node, label: String, action: String) -> void:
	var b := Button.new()
	b.text = label
	b.custom_minimum_size = Vector2(120, 120)
	b.focus_mode = Control.FOCUS_NONE
	b.button_down.connect(Input.action_press.bind(action))
	b.button_up.connect(Input.action_release.bind(action))
	parent.add_child(b)
